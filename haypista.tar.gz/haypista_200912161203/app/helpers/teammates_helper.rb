module TeammatesHelper
end
