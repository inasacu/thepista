require 'test_helper'

class ScorecardsHelperTest < ActionView::TestCase
end
