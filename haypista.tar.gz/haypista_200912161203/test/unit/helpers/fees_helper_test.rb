require 'test_helper'

class FeesHelperTest < ActionView::TestCase
end
