require 'test_helper'

class TypesHelperTest < ActionView::TestCase
end
