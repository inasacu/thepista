require 'test_helper'

class MatchesHelperTest < ActionView::TestCase
end
