require 'test_helper'

class MeetsHelperTest < ActionView::TestCase
end
