require 'test_helper'

class SchedulesHelperTest < ActionView::TestCase
end
