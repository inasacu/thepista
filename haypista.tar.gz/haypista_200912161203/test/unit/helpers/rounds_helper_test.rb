require 'test_helper'

class RoundsHelperTest < ActionView::TestCase
end
