require 'test_helper'

class ForumsHelperTest < ActionView::TestCase
end
