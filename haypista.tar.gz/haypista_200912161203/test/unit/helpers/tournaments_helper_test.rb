require 'test_helper'

class TournamentsHelperTest < ActionView::TestCase
end
