require 'test_helper'

class StandingsHelperTest < ActionView::TestCase
end
