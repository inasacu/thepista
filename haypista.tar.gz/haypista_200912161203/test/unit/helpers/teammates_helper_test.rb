require 'test_helper'

class TeammatesHelperTest < ActionView::TestCase
end
