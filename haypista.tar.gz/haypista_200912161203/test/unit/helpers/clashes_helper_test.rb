require 'test_helper'

class ClashesHelperTest < ActionView::TestCase
end
