require 'test_helper'

class MarkersHelperTest < ActionView::TestCase
end
