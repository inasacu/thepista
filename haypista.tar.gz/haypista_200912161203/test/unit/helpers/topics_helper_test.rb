require 'test_helper'

class TopicsHelperTest < ActionView::TestCase
end
