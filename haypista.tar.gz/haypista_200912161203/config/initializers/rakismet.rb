Rakismet::KEY  = '5969245b1d5e'
Rakismet::URL  = 'http://thepista.local/'
Rakismet::HOST = 'rest.akismet.com'
