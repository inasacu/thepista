HoptoadNotifier.configure do |config|
  config.api_key = 'b63604603b22867dddb914f893ae2104'
end