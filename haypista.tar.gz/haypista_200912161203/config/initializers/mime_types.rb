# Be sure to restart your server when you modify this file.

# Add new mime types for use in respond_to blocks:
# Mime::Type.register "text/richtext", :rtf
# Mime::Type.register_alias "text/html", :iphone



# ActionMailer::Base.delivery_method = :sendmail
# 
# # ActionMailer::Base.delivery_method = :smtp
# ActionMailer::Base.smtp_settings = {
#   :address  => "mail.haypista.com",
#   :port  => 26, 
#   :domain  => "haypista.com",
#   :user_name  => "support@haypista.com",
#   :password  => "m9$@4_4_$9d@",
#   :authentication  => :login
# }  
# ActionMailer::Base.raise_delivery_errors = true