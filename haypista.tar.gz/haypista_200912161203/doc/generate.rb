

ruby script/generate model activity
ruby script/generate model fee
ruby script/generate model feed
ruby script/generate model payment
ruby script/generate model practice

script/generate themed  activities activity --layout=application --with_will_paginate
script/generate themed  fees fee --layout=application --with_will_paginate
script/generate themed  feeds feed --layout=application --with_will_paginate
script/generate themed  payments payment --layout=application --with_will_paginate
script/generate themed  practices practice --layout=application --with_will_paginate


user_mailer



script/generate themed schedules schedule --layout=application --with_will_paginate










